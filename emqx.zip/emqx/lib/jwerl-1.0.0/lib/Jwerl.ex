# File: Jwerl.ex
# This file was generated from jwerl.beam
# Using rebar3_elixir (https://github.com/G-Corp/rebar3_elixir)
# MODIFY IT AT YOUR OWN RISK AND ONLY IF YOU KNOW WHAT YOU ARE DOING!
defmodule Jwerl do
  def unquote(:"sign")(arg1) do
    :erlang.apply(:"jwerl", :"sign", [arg1])
  end
  def unquote(:"sign")(arg1, arg2) do
    :erlang.apply(:"jwerl", :"sign", [arg1, arg2])
  end
  def unquote(:"sign")(arg1, arg2, arg3) do
    :erlang.apply(:"jwerl", :"sign", [arg1, arg2, arg3])
  end
  def unquote(:"verify")(arg1) do
    :erlang.apply(:"jwerl", :"verify", [arg1])
  end
  def unquote(:"verify")(arg1, arg2) do
    :erlang.apply(:"jwerl", :"verify", [arg1, arg2])
  end
  def unquote(:"verify")(arg1, arg2, arg3) do
    :erlang.apply(:"jwerl", :"verify", [arg1, arg2, arg3])
  end
  def unquote(:"verify")(arg1, arg2, arg3, arg4) do
    :erlang.apply(:"jwerl", :"verify", [arg1, arg2, arg3, arg4])
  end
  def unquote(:"header")(arg1) do
    :erlang.apply(:"jwerl", :"header", [arg1])
  end
end
